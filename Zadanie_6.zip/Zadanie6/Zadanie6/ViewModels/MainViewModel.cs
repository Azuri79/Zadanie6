﻿using CommunityToolkit.Mvvm.Input;
using System.Runtime.InteropServices;
using System.Windows.Input;

namespace Zadanie6.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    public MainViewModel()
    {
        SumCommand = new RelayCommand(Sum);
        SubstractCommand = new RelayCommand(Substract);
        MultiplyCommand = new RelayCommand(Multiply);
        DivideCommand = new RelayCommand(Divide);
    }

    private double firstNumber = 0.0f;
    public double FirstNumber
    {
        get => firstNumber;
        set => SetProperty(ref firstNumber, value);
    }

    private double secondNumber = 0.0f;
    public double SecondNumber
    {
        get => secondNumber;
        set => SetProperty(ref secondNumber, value);
    }

    private double? result;
    public double? Result
    {
        get => result;
        set => SetProperty(ref result, value);
    }

    public ICommand SumCommand { get; }
    private void Sum() => Result = FirstNumber + SecondNumber;

    public ICommand SubstractCommand { get; }
    private void Substract() => Result = FirstNumber - SecondNumber;

    public ICommand MultiplyCommand { get; }
    private void Multiply() => Result = FirstNumber * SecondNumber;

    public ICommand DivideCommand { get; }
    private void Divide() => Result = FirstNumber / SecondNumber;
}

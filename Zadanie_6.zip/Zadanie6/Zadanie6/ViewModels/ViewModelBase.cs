﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Zadanie6.ViewModels;

public class ViewModelBase : ObservableObject
{
}

﻿using Avalonia.Controls;

namespace Zadanie6.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}

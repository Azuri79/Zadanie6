﻿using Avalonia.Controls;

namespace Zadanie6.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
